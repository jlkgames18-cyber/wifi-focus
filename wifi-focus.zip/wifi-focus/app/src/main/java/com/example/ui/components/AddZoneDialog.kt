package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.util.DistractionCatalog

@Composable
fun AddZoneDialog(
    initialSsid: String = "",
    onDismiss: () -> Unit,
    onSave: (name: String, ssid: String, wallpaper: String, quote: String, blockedApps: List<String>) -> Unit
) {
    var zoneName by remember { mutableStateOf("") }
    var ssid by remember { mutableStateOf(initialSsid) }
    var selectedWallpaper by remember { mutableStateOf("img_focus_bg") }
    var quote by remember {
        mutableStateOf("التركيز هو الجسر بين أحلامك وإنجازاتك الحقيقية.")
    }
    var selectedApps by remember {
        mutableStateOf(DistractionCatalog.APPS.map { it.packageName })
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("add_zone_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إضافة شبكة تركيز ذكية",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Zone Name input
                Text(text = "اسم المكان / المنطقة", fontSize = 12.sp, color = Color(0xFF94A3B8))
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = zoneName,
                    onValueChange = { zoneName = it },
                    placeholder = { Text("مثلاً: مكتبة الجامعة، غرفة المذاكرة", fontSize = 13.sp, color = Color(0xFF64748B)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("zone_name_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // SSID input
                Text(text = "اسم شبكة الواي فاي (SSID)", fontSize = 12.sp, color = Color(0xFF94A3B8))
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = ssid,
                    onValueChange = { ssid = it },
                    placeholder = { Text("مثلاً: Library_WiFi_5G", fontSize = 13.sp, color = Color(0xFF64748B)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("zone_ssid_input"),
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8)
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Wallpaper selector
                Text(text = "خلفية الشاشة المحفزة", fontSize = 12.sp, color = Color(0xFF94A3B8))
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Option 1: Study Desk
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedWallpaper == "img_focus_bg") Color(0xFF0284C7).copy(alpha = 0.25f) else Color(0xFF1F2937),
                        border = BorderStroke(
                            1.5.dp,
                            if (selectedWallpaper == "img_focus_bg") Color(0xFF38BDF8) else Color(0xFF374151)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedWallpaper = "img_focus_bg" }
                            .testTag("wallpaper_desk_option")
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "مكتب المذاكرة 📖",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(text = "إضاءة دافئة وهدوء", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        }
                    }

                    // Option 2: Grand Library
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedWallpaper == "img_library_bg") Color(0xFF0284C7).copy(alpha = 0.25f) else Color(0xFF1F2937),
                        border = BorderStroke(
                            1.5.dp,
                            if (selectedWallpaper == "img_library_bg") Color(0xFF38BDF8) else Color(0xFF374151)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedWallpaper = "img_library_bg" }
                            .testTag("wallpaper_library_option")
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "مكتبة كبرى 🏛️",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(text = "أجواء وقار ومعرفة", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Custom Quote
                Text(text = "عبارة التحفيز المخصصة", fontSize = 12.sp, color = Color(0xFF94A3B8))
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = quote,
                    onValueChange = { quote = it },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Save button
                Button(
                    onClick = {
                        if (zoneName.isNotBlank() && ssid.isNotBlank()) {
                            onSave(zoneName.trim(), ssid.trim(), selectedWallpaper, quote.trim(), selectedApps)
                        }
                    },
                    enabled = zoneName.isNotBlank() && ssid.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_zone_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "حفظ وتفعيل الشبكة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
