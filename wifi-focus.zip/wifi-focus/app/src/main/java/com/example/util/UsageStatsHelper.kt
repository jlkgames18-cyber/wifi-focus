package com.example.util

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings

data class DistractingApp(
    val packageName: String,
    val nameArabic: String,
    val nameEnglish: String,
    val category: String,
    val defaultBlocked: Boolean = true
)

object DistractionCatalog {
    val APPS = listOf(
        DistractingApp("com.instagram.android", "انستغرام", "Instagram", "Social Media"),
        DistractingApp("com.zhiliaoapp.musically", "تيك توك", "TikTok", "Short Videos"),
        DistractingApp("com.google.android.youtube", "يوتيوب", "YouTube", "Video Streaming"),
        DistractingApp("com.twitter.android", "إكس (تويتر)", "X / Twitter", "Social Media"),
        DistractingApp("com.snapchat.android", "سناب شات", "Snapchat", "Social Media"),
        DistractingApp("com.facebook.katana", "فيسبوك", "Facebook", "Social Media"),
        DistractingApp("com.reddit.frontpage", "ريديت", "Reddit", "Social Media"),
        DistractingApp("com.netflix.mediaclient", "نتفلكس", "Netflix", "Entertainment"),
        DistractingApp("com.supercell.clashofclans", "ألعاب الموبايل", "Mobile Games", "Gaming")
    )

    fun getAppName(packageName: String): String {
        return APPS.find { it.packageName == packageName }?.let { "${it.nameArabic} (${it.nameEnglish})" }
            ?: packageName
    }
}

class UsageStatsHelper(private val context: Context) {

    private val usageStatsManager =
        context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager

    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettings() {
        try {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    /**
     * Checks the currently active foreground package in the last 15 seconds.
     */
    fun getForegroundAppPackage(): String? {
        if (!hasUsageStatsPermission() || usageStatsManager == null) return null

        val endTime = System.currentTimeMillis()
        val startTime = endTime - 15000

        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        val event = UsageEvents.Event()
        var lastForegroundPackage: String? = null

        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                lastForegroundPackage = event.packageName
            }
        }
        return lastForegroundPackage
    }
}
