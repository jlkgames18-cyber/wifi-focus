package com.example.data

import com.example.data.dao.FocusDao
import com.example.data.entity.DistractionLog
import com.example.data.entity.FocusSession
import com.example.data.entity.FocusZone
import kotlinx.coroutines.flow.Flow

class FocusRepository(private val dao: FocusDao) {

    val allZones: Flow<List<FocusZone>> = dao.getAllZones()
    val allSessions: Flow<List<FocusSession>> = dao.getAllSessions()
    val recentDistractions: Flow<List<DistractionLog>> = dao.getRecentDistractions()
    val totalFocusSeconds: Flow<Long?> = dao.getTotalFocusSeconds()
    val totalSessionsCount: Flow<Int> = dao.getTotalSessionsCount()
    val totalDistractionsBlocked: Flow<Int> = dao.getTotalDistractionsBlocked()

    suspend fun getZoneBySsid(ssid: String): FocusZone? {
        val cleanSsid = ssid.trim('\"')
        return dao.getZoneBySsid(cleanSsid) ?: dao.getZoneBySsid(ssid)
    }

    suspend fun getZoneById(id: Long): FocusZone? = dao.getZoneById(id)

    suspend fun insertZone(zone: FocusZone): Long = dao.insertZone(zone)

    suspend fun updateZone(zone: FocusZone) = dao.updateZone(zone)

    suspend fun deleteZone(id: Long) = dao.deleteZoneById(id)

    suspend fun getActiveSession(): FocusSession? = dao.getActiveSession()

    suspend fun startSession(zone: FocusZone): FocusSession {
        val active = dao.getActiveSession()
        if (active != null) {
            // End active session first
            val duration = (System.currentTimeMillis() - active.startTime) / 1000
            dao.updateSession(active.copy(endTime = System.currentTimeMillis(), durationSeconds = duration))
        }
        val newSession = FocusSession(
            zoneId = zone.id,
            zoneName = zone.name,
            ssid = zone.ssid,
            startTime = System.currentTimeMillis()
        )
        val id = dao.insertSession(newSession)
        return newSession.copy(id = id)
    }

    suspend fun endActiveSession(): FocusSession? {
        val active = dao.getActiveSession() ?: return null
        val duration = (System.currentTimeMillis() - active.startTime) / 1000
        val updated = active.copy(
            endTime = System.currentTimeMillis(),
            durationSeconds = duration
        )
        dao.updateSession(updated)
        return updated
    }

    suspend fun recordDistraction(packageName: String, appName: String, zoneName: String) {
        dao.insertDistraction(
            DistractionLog(
                packageName = packageName,
                appName = appName,
                zoneName = zoneName
            )
        )
        val active = dao.getActiveSession()
        if (active != null) {
            dao.updateSession(active.copy(distractionsBlocked = active.distractionsBlocked + 1))
        }
    }
}
