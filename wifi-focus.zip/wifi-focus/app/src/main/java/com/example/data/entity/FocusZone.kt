package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "focus_zones")
data class FocusZone(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ssid: String,
    val bssid: String = "",
    val name: String,
    val wallpaperResName: String = "img_focus_bg",
    val customQuote: String = "ركّز على هدفك، مستقبلك يُصنع الآن في هذه البيئة.",
    val autoFilterEnabled: Boolean = true,
    val blockedApps: String = "com.instagram.android,com.zhiliaoapp.musically,com.google.android.youtube,com.twitter.android,com.snapchat.android,com.facebook.katana",
    val createdAt: Long = System.currentTimeMillis()
)
