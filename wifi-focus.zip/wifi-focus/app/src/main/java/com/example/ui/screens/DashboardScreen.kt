package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkWifi
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.FocusZone
import com.example.ui.UiFocusState
import com.example.util.WifiState

@Composable
fun DashboardScreen(
    uiState: UiFocusState,
    wifiState: WifiState,
    zones: List<FocusZone>,
    totalFocusSeconds: Long,
    totalDistractionsBlocked: Int,
    onEnterZenMode: () -> Unit,
    onSimulateWifi: (String?) -> Unit,
    onResetHardwareWifi: () -> Unit,
    onAddCurrentWifi: (String) -> Unit,
    onOpenUsageSettings: () -> Unit,
    onOpenAddZoneDialog: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0E17))
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("dashboard_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Hero Environment Status Card
        val isFocusActive = uiState.isFocusActive
        val activeZone = uiState.activeZone

        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isFocusActive) Color(0xFF0D2538) else Color(0xFF131B2A)
            ),
            border = BorderStroke(
                1.5.dp,
                if (isFocusActive) Color(0xFF0284C7) else Color(0xFF1E293B)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("hero_status_card")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Pulse badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isFocusActive) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFF64748B).copy(alpha = 0.15f),
                    border = BorderStroke(
                        1.dp,
                        if (isFocusActive) Color(0xFF10B981) else Color(0xFF64748B)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isFocusActive) Color(0xFF10B981) else Color(0xFF94A3B8))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isFocusActive) "وضع التصفية والتركيز الذكي نشط" else "الهاتف بوضعه الطبيعي",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isFocusActive) Color(0xFF34D399) else Color(0xFFCBD5E1)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Wi-Fi Icon & Name
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            if (isFocusActive) Color(0xFF0284C7).copy(alpha = 0.2f) else Color(0xFF1E293B)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (wifiState.isConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
                        contentDescription = null,
                        tint = if (isFocusActive) Color(0xFF38BDF8) else if (wifiState.isConnected) Color.White else Color(0xFFEF4444),
                        modifier = Modifier.size(34.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (wifiState.isConnected) {
                        if (wifiState.ssid.isNotEmpty()) wifiState.ssid else "شبكة واي فاي متصلة"
                    } else {
                        "غير متصل بأي شبكة واي فاي"
                    },
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                if (isFocusActive && activeZone != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "تم التعرف على المنطقة: ${activeZone.name}",
                        fontSize = 14.sp,
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isFocusActive) {
                        "يقوم التطبيق حالياً بتصفية المشتتات وإخفاء السوشيال ميديا تلقائياً. عند مغادرة هذه الشبكة يعود الهاتف لطبيعته."
                    } else {
                        "بمجرد اتصالك بشبكة إحدى مناطق تركيزك (مثل المكتبة أو غرفة المذاكرة)، سيتحول الهاتف تلقائياً لوضع التركيز."
                    },
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Action button: Enter Zen Launcher
                Button(
                    onClick = onEnterZenMode,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isFocusActive) Color(0xFF0284C7) else Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("enter_zen_launcher_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isFocusActive) "عرض واجهة التركيز المصفاة (Zen)" else "معاينة واجهة التركيز (Zen Mode)",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }

                // If currently connected to an unregistered Wi-Fi, offer 1-tap add
                if (wifiState.isConnected && wifiState.ssid.isNotBlank() && !isFocusActive) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { onAddCurrentWifi(wifiState.ssid) },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_current_wifi_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "تعيين (${wifiState.ssid}) كمنطقة تركيز جديدة",
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Network Simulator Section (for instant testing anywhere!)
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2A)),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "محاكي البيئة والواي فاي (للاختبار السريع)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    if (wifiState.isSimulated) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF0284C7).copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "وضع المحاكاة نشط",
                                fontSize = 10.sp,
                                color = Color(0xFF38BDF8),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "اضغط على أي شبكة لتجربة التبديل التلقائي الفوري للهاتف بدون الحاجة للتواجد الفعلي في المكان:",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    // Option 1: University Library
                    item {
                        SimulationChip(
                            label = "مكتبة الجامعة 🏛️",
                            subLabel = "Library_WiFi",
                            isSelected = wifiState.ssid == "Library_WiFi",
                            onClick = { onSimulateWifi("Library_WiFi") },
                            testTag = "sim_library_wifi"
                        )
                    }

                    // Option 2: Study Room
                    item {
                        SimulationChip(
                            label = "غرفة المذاكرة 📖",
                            subLabel = "Study_Room_5G",
                            isSelected = wifiState.ssid == "Study_Room_5G",
                            onClick = { onSimulateWifi("Study_Room_5G") },
                            testTag = "sim_study_wifi"
                        )
                    }

                    // Option 3: Regular Home/Cafe WiFi (Not a focus zone)
                    item {
                        SimulationChip(
                            label = "واي فاي عادي ☕",
                            subLabel = "Cafe_WiFi_Guest",
                            isSelected = wifiState.ssid == "Cafe_WiFi_Guest",
                            onClick = { onSimulateWifi("Cafe_WiFi_Guest") },
                            testTag = "sim_cafe_wifi"
                        )
                    }

                    // Option 4: Disconnected
                    item {
                        SimulationChip(
                            label = "قطع الاتصال ❌",
                            subLabel = "Disconnected",
                            isSelected = !wifiState.isConnected,
                            onClick = { onSimulateWifi(null) },
                            testTag = "sim_disconnect_wifi"
                        )
                    }

                    // Option 5: Reset to Real Hardware
                    item {
                        SimulationChip(
                            label = "الواي فاي الفعلي 📡",
                            subLabel = "Hardware Wi-Fi",
                            isSelected = !wifiState.isSimulated,
                            onClick = onResetHardwareWifi,
                            testTag = "sim_real_hardware"
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Stats Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Hours
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2A)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Icon(
                        imageVector = Icons.Default.HourglassBottom,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    val hours = totalFocusSeconds / 3600
                    val minutes = (totalFocusSeconds % 3600) / 60
                    Text(
                        text = "${hours}س ${minutes}د",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "إجمالي ساعات التركيز",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            // Distractions Prevented
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2A)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = null,
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "$totalDistractionsBlocked محاولة",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "تشتيت تم صده بالدرع",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // App Usage Access Permission Status Card
        if (!uiState.hasUsageStatsPermission) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1917)),
                border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "إذن الوصول لبيانات الاستخدام",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "مطلوب لتنبيهك تلقائياً إذا فتحت تطبيقاً مشتتاً في المكان الخطأ (0$ بدون تكلفة).",
                            fontSize = 11.sp,
                            color = Color(0xFFD6D3D1),
                            lineHeight = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onOpenUsageSettings,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = "تفعيل", fontSize = 12.sp, color = Color.White)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun SimulationChip(
    label: String,
    subLabel: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) Color(0xFF0284C7).copy(alpha = 0.25f) else Color(0xFF0F172A),
        border = BorderStroke(
            1.5.dp,
            if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155)
        ),
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color(0xFF38BDF8) else Color.White
            )
            Text(
                text = subLabel,
                fontSize = 10.sp,
                color = Color(0xFF94A3B8)
            )
        }
    }
}
