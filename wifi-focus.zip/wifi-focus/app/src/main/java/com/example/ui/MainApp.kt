package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FilterDrama
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AddZoneDialog
import com.example.ui.components.DistractionShieldDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.screens.ZenFocusScreen
import com.example.ui.screens.ZonesScreen

sealed class NavTab(val title: String, val testTag: String) {
    data object Dashboard : NavTab("الرئيسية", "tab_dashboard")
    data object Zones : NavTab("شبكات التركيز", "tab_zones")
    data object Stats : NavTab("الإحصائيات", "tab_stats")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: FocusViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val wifiState by viewModel.wifiState.collectAsStateWithLifecycle()
    val zones by viewModel.zones.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val recentDistractions by viewModel.recentDistractions.collectAsStateWithLifecycle()
    val totalFocusSeconds by viewModel.totalFocusSeconds.collectAsStateWithLifecycle()
    val totalDistractionsBlocked by viewModel.totalDistractionsBlocked.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf<NavTab>(NavTab.Dashboard) }
    var initialDialogSsid by remember { mutableStateOf("") }

    // If Zen Screen is active (auto-switched when connecting to study Wi-Fi or manually toggled)
    if (uiState.isZenScreenActive) {
        ZenFocusScreen(
            activeZone = uiState.activeZone,
            elapsedSeconds = uiState.sessionElapsedSeconds,
            distractionApp = uiState.distractionShieldApp,
            onExitZen = { viewModel.setZenScreenActive(false) },
            onDistractionTriggered = { app -> viewModel.triggerDistractionShield(app) },
            onDismissDistraction = { viewModel.dismissDistractionShield() }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "WiFi Focus",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        // Real-time Wi-Fi indicator pill
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (uiState.isFocusActive) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF1E293B)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (uiState.isFocusActive) Color(0xFF10B981) else Color(0xFF94A3B8))
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = if (wifiState.isConnected) {
                                        if (wifiState.ssid.isNotEmpty()) wifiState.ssid else "متصل"
                                    } else {
                                        "غير متصل"
                                    },
                                    fontSize = 10.sp,
                                    color = if (uiState.isFocusActive) Color(0xFF34D399) else Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                },
                actions = {
                    // Quick Zen Launcher Button
                    IconButton(
                        onClick = { viewModel.setZenScreenActive(true) },
                        modifier = Modifier.testTag("zen_quick_launch_icon")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = "Open Zen Launcher",
                            tint = if (uiState.isFocusActive) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0A0E17)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF111827),
                contentColor = Color.White
            ) {
                // Dashboard Tab
                NavigationBarItem(
                    selected = currentTab is NavTab.Dashboard,
                    onClick = { currentTab = NavTab.Dashboard },
                    icon = {
                        Icon(imageVector = Icons.Default.Dashboard, contentDescription = "Dashboard")
                    },
                    label = { Text(NavTab.Dashboard.title, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0284C7),
                        selectedTextColor = Color(0xFF38BDF8),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B),
                        indicatorColor = Color(0xFF0284C7).copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag(NavTab.Dashboard.testTag)
                )

                // Zones Tab
                NavigationBarItem(
                    selected = currentTab is NavTab.Zones,
                    onClick = { currentTab = NavTab.Zones },
                    icon = {
                        Icon(imageVector = Icons.Default.Wifi, contentDescription = "Focus Zones")
                    },
                    label = { Text(NavTab.Zones.title, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0284C7),
                        selectedTextColor = Color(0xFF38BDF8),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B),
                        indicatorColor = Color(0xFF0284C7).copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag(NavTab.Zones.testTag)
                )

                // Stats Tab
                NavigationBarItem(
                    selected = currentTab is NavTab.Stats,
                    onClick = { currentTab = NavTab.Stats },
                    icon = {
                        Icon(imageVector = Icons.Default.Analytics, contentDescription = "Analytics")
                    },
                    label = { Text(NavTab.Stats.title, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0284C7),
                        selectedTextColor = Color(0xFF38BDF8),
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B),
                        indicatorColor = Color(0xFF0284C7).copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag(NavTab.Stats.testTag)
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "navTransition"
            ) { targetTab ->
                when (targetTab) {
                    is NavTab.Dashboard -> DashboardScreen(
                        uiState = uiState,
                        wifiState = wifiState,
                        zones = zones,
                        totalFocusSeconds = totalFocusSeconds ?: 0L,
                        totalDistractionsBlocked = totalDistractionsBlocked,
                        onEnterZenMode = { viewModel.setZenScreenActive(true) },
                        onSimulateWifi = { ssid -> viewModel.simulateWifi(ssid) },
                        onResetHardwareWifi = { viewModel.resetToHardwareWifi() },
                        onAddCurrentWifi = { currentSsid ->
                            initialDialogSsid = currentSsid
                            viewModel.showAddZoneDialog(true)
                        },
                        onOpenUsageSettings = { viewModel.openUsageSettings() },
                        onOpenAddZoneDialog = {
                            initialDialogSsid = wifiState.ssid
                            viewModel.showAddZoneDialog(true)
                        }
                    )

                    is NavTab.Zones -> ZonesScreen(
                        zones = zones,
                        activeZoneId = uiState.activeZone?.id,
                        onToggleAutoFilter = { zone, enabled ->
                            viewModel.toggleZoneAutoFilter(zone, enabled)
                        },
                        onDeleteZone = { id -> viewModel.deleteZone(id) },
                        onOpenAddZoneDialog = {
                            initialDialogSsid = wifiState.ssid
                            viewModel.showAddZoneDialog(true)
                        }
                    )

                    is NavTab.Stats -> StatsScreen(
                        sessions = sessions,
                        recentDistractions = recentDistractions,
                        totalFocusSeconds = totalFocusSeconds ?: 0L,
                        totalDistractionsBlocked = totalDistractionsBlocked
                    )
                }
            }
        }
    }

    // Add Zone Dialog
    if (uiState.showAddZoneDialog) {
        AddZoneDialog(
            initialSsid = initialDialogSsid,
            onDismiss = { viewModel.showAddZoneDialog(false) },
            onSave = { name, ssid, wallpaper, quote, blockedApps ->
                viewModel.addNewZone(name, ssid, wallpaper, quote, blockedApps)
                viewModel.showAddZoneDialog(false)
            }
        )
    }

    // Distraction Shield Dialog
    if (uiState.distractionShieldApp != null) {
        DistractionShieldDialog(
            app = uiState.distractionShieldApp!!,
            zoneName = uiState.activeZone?.name ?: "منطقة التركيز",
            onDismiss = { viewModel.dismissDistractionShield() }
        )
    }
}
