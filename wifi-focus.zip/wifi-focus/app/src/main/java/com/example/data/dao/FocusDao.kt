package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.DistractionLog
import com.example.data.entity.FocusSession
import com.example.data.entity.FocusZone
import kotlinx.coroutines.flow.Flow

@Dao
interface FocusDao {

    // Zones
    @Query("SELECT * FROM focus_zones ORDER BY createdAt DESC")
    fun getAllZones(): Flow<List<FocusZone>>

    @Query("SELECT * FROM focus_zones WHERE ssid = :ssid LIMIT 1")
    suspend fun getZoneBySsid(ssid: String): FocusZone?

    @Query("SELECT * FROM focus_zones WHERE id = :id LIMIT 1")
    suspend fun getZoneById(id: Long): FocusZone?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertZone(zone: FocusZone): Long

    @Update
    suspend fun updateZone(zone: FocusZone)

    @Query("DELETE FROM focus_zones WHERE id = :id")
    suspend fun deleteZoneById(id: Long)

    @Query("SELECT COUNT(*) FROM focus_zones")
    suspend fun getZonesCount(): Int

    // Sessions
    @Query("SELECT * FROM focus_sessions ORDER BY startTime DESC")
    fun getAllSessions(): Flow<List<FocusSession>>

    @Query("SELECT * FROM focus_sessions WHERE endTime IS NULL ORDER BY startTime DESC LIMIT 1")
    suspend fun getActiveSession(): FocusSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: FocusSession): Long

    @Update
    suspend fun updateSession(session: FocusSession)

    @Query("SELECT SUM(durationSeconds) FROM focus_sessions WHERE endTime IS NOT NULL")
    fun getTotalFocusSeconds(): Flow<Long?>

    @Query("SELECT COUNT(*) FROM focus_sessions")
    fun getTotalSessionsCount(): Flow<Int>

    // Distraction logs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDistraction(log: DistractionLog): Long

    @Query("SELECT * FROM distraction_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentDistractions(): Flow<List<DistractionLog>>

    @Query("SELECT COUNT(*) FROM distraction_logs")
    fun getTotalDistractionsBlocked(): Flow<Int>
}
