package com.example.util

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class WifiState(
    val isConnected: Boolean = false,
    val ssid: String = "",
    val bssid: String = "",
    val rssi: Int = 0,
    val linkSpeedMbps: Int = 0,
    val isSimulated: Boolean = false,
    val simulatedNetworkName: String? = null
)

class WifiMonitor(private val context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private val _wifiState = MutableStateFlow(getCurrentHardwareWifiState())
    val wifiState: StateFlow<WifiState> = _wifiState.asStateFlow()

    private var simulatedZoneSsid: String? = null

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            updateWifiState()
        }

        override fun onLost(network: Network) {
            updateWifiState()
        }

        override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities
        ) {
            updateWifiState()
        }
    }

    init {
        try {
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build()
            connectivityManager?.registerNetworkCallback(request, networkCallback)
        } catch (e: Exception) {
            // Fallback: registerDefaultNetworkCallback if supported
            try {
                connectivityManager?.registerDefaultNetworkCallback(networkCallback)
            } catch (_: Exception) {}
        }
        updateWifiState()
    }

    fun updateWifiState() {
        if (simulatedZoneSsid != null) {
            // Simulated state
            _wifiState.value = WifiState(
                isConnected = true,
                ssid = simulatedZoneSsid ?: "",
                bssid = "02:00:00:00:00:00",
                rssi = -45,
                linkSpeedMbps = 300,
                isSimulated = true,
                simulatedNetworkName = simulatedZoneSsid
            )
            return
        }

        _wifiState.value = getCurrentHardwareWifiState()
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentHardwareWifiState(): WifiState {
        val cm = connectivityManager ?: return WifiState()
        val wm = wifiManager

        val activeNetwork = cm.activeNetwork ?: return WifiState(isConnected = false)
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return WifiState(isConnected = false)

        val isWifi = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        if (!isWifi) {
            return WifiState(isConnected = false)
        }

        var ssid = ""
        var bssid = ""
        var rssi = 0
        var linkSpeed = 0

        // Attempt to extract WifiInfo from capabilities on Android Q+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val info = capabilities.transportInfo as? WifiInfo
            if (info != null) {
                ssid = info.ssid
                bssid = info.bssid ?: ""
                rssi = info.rssi
                linkSpeed = info.linkSpeed
            }
        }

        // Fallback to WifiManager
        if (ssid.isEmpty() || ssid == "<unknown ssid>") {
            try {
                val connectionInfo = wm?.connectionInfo
                if (connectionInfo != null) {
                    ssid = connectionInfo.ssid ?: ""
                    if (bssid.isEmpty()) bssid = connectionInfo.bssid ?: ""
                    if (rssi == 0) rssi = connectionInfo.rssi
                    if (linkSpeed == 0) linkSpeed = connectionInfo.linkSpeed
                }
            } catch (_: Exception) {}
        }

        // Clean quotes from SSID (e.g. "MyWifi" -> MyWifi)
        val cleanSsid = ssid.trim('\"')

        return WifiState(
            isConnected = true,
            ssid = if (cleanSsid == "<unknown ssid>") "" else cleanSsid,
            bssid = bssid,
            rssi = rssi,
            linkSpeedMbps = linkSpeed,
            isSimulated = false
        )
    }

    fun simulateConnection(ssid: String?) {
        simulatedZoneSsid = ssid
        updateWifiState()
    }

    fun stopMonitoring() {
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (_: Exception) {}
    }
}
