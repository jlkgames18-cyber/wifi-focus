package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "focus_sessions")
data class FocusSession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val zoneId: Long,
    val zoneName: String,
    val ssid: String,
    val startTime: Long,
    val endTime: Long? = null,
    val durationSeconds: Long = 0,
    val distractionsBlocked: Int = 0
)
