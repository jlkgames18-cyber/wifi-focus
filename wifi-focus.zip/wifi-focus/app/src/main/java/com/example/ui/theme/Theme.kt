package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = FocusBlueLight,
    onPrimary = Color(0xFF003258),
    primaryContainer = Color(0xFF00497D),
    onPrimaryContainer = Color(0xFFD1E4FF),
    secondary = FocusTealLight,
    onSecondary = Color(0xFF003734),
    secondaryContainer = Color(0xFF004F4C),
    onSecondaryContainer = Color(0xFF6FF7EE),
    tertiary = FocusAmberLight,
    background = FocusDarkBg,
    onBackground = Color(0xFFF1F5F9),
    surface = FocusDarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = FocusDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5E1)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = FocusBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1E4FF),
    onPrimaryContainer = Color(0xFF001D36),
    secondary = FocusTeal,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF6FF7EE),
    onSecondaryContainer = Color(0xFF00201E),
    tertiary = FocusAmber,
    background = FocusLightBg,
    onBackground = Color(0xFF0F172A),
    surface = FocusLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = FocusLightSurfaceVariant,
    onSurfaceVariant = Color(0xFF475569)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

