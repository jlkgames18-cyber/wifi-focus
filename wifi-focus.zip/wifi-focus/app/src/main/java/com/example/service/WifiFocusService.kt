package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.FocusRepository
import com.example.util.WifiMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class WifiFocusService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var wifiMonitor: WifiMonitor
    private lateinit var repository: FocusRepository

    companion object {
        const val CHANNEL_ID = "wifi_focus_channel"
        const val NOTIFICATION_ID = 1001

        fun startService(context: Context) {
            val intent = Intent(context, WifiFocusService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, WifiFocusService::class.java)
            context.stopService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("جاري فحص شبكة الواي فاي..."))

        val db = AppDatabase.getInstance(applicationContext)
        repository = FocusRepository(db.focusDao())
        wifiMonitor = WifiMonitor(applicationContext)

        serviceScope.launch {
            wifiMonitor.wifiState.collectLatest { state ->
                if (state.isConnected && state.ssid.isNotEmpty()) {
                    val zone = repository.getZoneBySsid(state.ssid)
                    if (zone != null && zone.autoFilterEnabled) {
                        repository.startSession(zone)
                        updateNotification("متصل بـ: ${zone.name} • وضع التركيز وتصفية الهاتف نشط")
                    } else {
                        repository.endActiveSession()
                        updateNotification("متصل بـ: ${state.ssid} • خارج مناطق التركيز")
                    }
                } else {
                    repository.endActiveSession()
                    updateNotification("غير متصل بالواي فاي • الهاتف بوضعه الطبيعي")
                }
            }
        }
    }

    private fun updateNotification(text: String) {
        val notification = buildNotification(text)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(contentText: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("WiFi Focus • تركيز تلقائي")
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "مراقبة شبكة الواي فاي للتركيز",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار مستمر عند مراقبة شبكات التركيز وتصفية المشتتات"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        wifiMonitor.stopMonitoring()
        serviceScope.cancel()
    }
}
