package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.FocusDao
import com.example.data.entity.DistractionLog
import com.example.data.entity.FocusSession
import com.example.data.entity.FocusZone
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [FocusZone::class, FocusSession::class, DistractionLog::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun focusDao(): FocusDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "wifi_focus_database.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Prepopulate default focus zones for instant delightful user experience
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getInstance(context).focusDao()
                            dao.insertZone(
                                FocusZone(
                                    ssid = "Library_WiFi",
                                    name = "مكتبة الجامعة (University Library)",
                                    wallpaperResName = "img_library_bg",
                                    customQuote = "الصمت والتركيز هما سر الإنجاز العظيم في رحاب المعرفة.",
                                    autoFilterEnabled = true
                                )
                            )
                            dao.insertZone(
                                FocusZone(
                                    ssid = "Study_Room_5G",
                                    name = "غرفة المذاكرة (Study Room)",
                                    wallpaperResName = "img_focus_bg",
                                    customQuote = "كل دقيقة تركز فيها الآن تقربك من حلمك ومستقبلك.",
                                    autoFilterEnabled = true
                                )
                            )
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
