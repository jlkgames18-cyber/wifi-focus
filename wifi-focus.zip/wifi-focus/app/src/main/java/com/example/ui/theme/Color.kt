package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FocusBlue = Color(0xFF0284C7)
val FocusBlueLight = Color(0xFF38BDF8)
val FocusTeal = Color(0xFF0D9488)
val FocusTealLight = Color(0xFF2DD4BF)
val FocusAmber = Color(0xFFD97706)
val FocusAmberLight = Color(0xFFFBBF24)
val FocusEmerald = Color(0xFF059669)
val FocusEmeraldLight = Color(0xFF34D399)

val FocusDarkBg = Color(0xFF0A0E17)
val FocusDarkSurface = Color(0xFF111827)
val FocusDarkSurfaceVariant = Color(0xFF1F2937)

val FocusLightBg = Color(0xFFF8FAFC)
val FocusLightSurface = Color(0xFFFFFFFF)
val FocusLightSurfaceVariant = Color(0xFFF1F5F9)

