package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.FocusRepository
import com.example.data.entity.DistractionLog
import com.example.data.entity.FocusSession
import com.example.data.entity.FocusZone
import com.example.service.WifiFocusService
import com.example.util.DistractionCatalog
import com.example.util.DistractingApp
import com.example.util.UsageStatsHelper
import com.example.util.WifiMonitor
import com.example.util.WifiState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiFocusState(
    val activeZone: FocusZone? = null,
    val isFocusActive: Boolean = false,
    val isZenScreenActive: Boolean = false,
    val sessionElapsedSeconds: Long = 0,
    val currentQuote: String = "ركّز على هدفك، مستقبلك يُصنع الآن في هذه البيئة.",
    val hasUsageStatsPermission: Boolean = false,
    val distractionShieldApp: DistractingApp? = null,
    val showAddZoneDialog: Boolean = false,
    val simulationModeEnabled: Boolean = false
)

class FocusViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    val repository = FocusRepository(db.focusDao())
    val wifiMonitor = WifiMonitor(application)
    val usageHelper = UsageStatsHelper(application)

    val wifiState: StateFlow<WifiState> = wifiMonitor.wifiState

    val zones: StateFlow<List<FocusZone>> = repository.allZones
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessions: StateFlow<List<FocusSession>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentDistractions: StateFlow<List<DistractionLog>> = repository.recentDistractions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalFocusSeconds: StateFlow<Long?> = repository.totalFocusSeconds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalDistractionsBlocked: StateFlow<Int> = repository.totalDistractionsBlocked
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _uiState = MutableStateFlow(UiFocusState())
    val uiState: StateFlow<UiFocusState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var usageWatcherJob: Job? = null

    init {
        try {
            WifiFocusService.startService(application)
        } catch (_: Exception) {}

        checkPermissions()

        // Watch Wi-Fi state changes and match with registered Focus Zones
        viewModelScope.launch {
            wifiMonitor.wifiState.collectLatest { state ->
                handleWifiStateChange(state)
            }
        }

        // Start background polling for distraction app detection if permission granted
        startUsageWatcher()
    }

    fun checkPermissions() {
        _uiState.value = _uiState.value.copy(
            hasUsageStatsPermission = usageHelper.hasUsageStatsPermission()
        )
    }

    fun openUsageSettings() {
        usageHelper.openUsageAccessSettings()
    }

    private suspend fun handleWifiStateChange(state: WifiState) {
        if (!state.isConnected || state.ssid.isEmpty()) {
            // Left Wi-Fi network -> Exit focus mode automatically
            repository.endActiveSession()
            stopTimer()
            _uiState.value = _uiState.value.copy(
                activeZone = null,
                isFocusActive = false,
                isZenScreenActive = false,
                sessionElapsedSeconds = 0
            )
            return
        }

        val zone = repository.getZoneBySsid(state.ssid)
        if (zone != null && zone.autoFilterEnabled) {
            // Entered registered Focus Zone -> Auto trigger Phone Filter / Focus Mode!
            repository.startSession(zone)
            startTimer()
            _uiState.value = _uiState.value.copy(
                activeZone = zone,
                isFocusActive = true,
                isZenScreenActive = true, // Switch phone interface automatically to Zen Minimalist Screen
                currentQuote = zone.customQuote
            )
        } else {
            // Connected to regular, non-focus Wi-Fi -> Normal phone behavior
            repository.endActiveSession()
            stopTimer()
            _uiState.value = _uiState.value.copy(
                activeZone = null,
                isFocusActive = false,
                isZenScreenActive = false,
                sessionElapsedSeconds = 0
            )
        }
    }

    private fun startTimer() {
        stopTimer()
        timerJob = viewModelScope.launch {
            var seconds = 0L
            while (true) {
                delay(1000)
                seconds++
                _uiState.value = _uiState.value.copy(sessionElapsedSeconds = seconds)
            }
        }
    }

    private fun stopTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    private fun startUsageWatcher() {
        usageWatcherJob?.cancel()
        usageWatcherJob = viewModelScope.launch {
            while (true) {
                delay(3000)
                if (_uiState.value.isFocusActive && usageHelper.hasUsageStatsPermission()) {
                    val foregroundPackage = usageHelper.getForegroundAppPackage()
                    if (foregroundPackage != null && foregroundPackage != getApplication<Application>().packageName) {
                        val activeZone = _uiState.value.activeZone
                        val blockedList = activeZone?.blockedApps?.split(",") ?: emptyList()
                        if (blockedList.any { it.trim() == foregroundPackage }) {
                            val distractingApp = DistractionCatalog.APPS.find { it.packageName == foregroundPackage }
                                ?: DistractingApp(foregroundPackage, foregroundPackage, foregroundPackage, "App")
                            triggerDistractionShield(distractingApp)
                        }
                    }
                }
            }
        }
    }

    fun triggerDistractionShield(app: DistractingApp) {
        val zoneName = _uiState.value.activeZone?.name ?: "منطقة التركيز"
        viewModelScope.launch {
            repository.recordDistraction(app.packageName, app.nameArabic, zoneName)
        }
        _uiState.value = _uiState.value.copy(distractionShieldApp = app)
    }

    fun dismissDistractionShield() {
        _uiState.value = _uiState.value.copy(distractionShieldApp = null)
    }

    fun setZenScreenActive(active: Boolean) {
        _uiState.value = _uiState.value.copy(isZenScreenActive = active)
    }

    fun simulateWifi(ssid: String?) {
        wifiMonitor.simulateConnection(ssid)
        _uiState.value = _uiState.value.copy(
            simulationModeEnabled = ssid != null
        )
    }

    fun resetToHardwareWifi() {
        wifiMonitor.simulateConnection(null)
        _uiState.value = _uiState.value.copy(simulationModeEnabled = false)
        wifiMonitor.updateWifiState()
    }

    fun addNewZone(
        name: String,
        ssid: String,
        wallpaperResName: String,
        customQuote: String,
        blockedAppsList: List<String>
    ) {
        viewModelScope.launch {
            val zone = FocusZone(
                name = name,
                ssid = ssid.trim('\"'),
                wallpaperResName = wallpaperResName,
                customQuote = customQuote.ifBlank { "ركّز على هدفك، مستقبلك يُصنع الآن في هذه البيئة." },
                blockedApps = blockedAppsList.joinToString(","),
                autoFilterEnabled = true
            )
            repository.insertZone(zone)
            wifiMonitor.updateWifiState()
        }
    }

    fun deleteZone(id: Long) {
        viewModelScope.launch {
            repository.deleteZone(id)
            wifiMonitor.updateWifiState()
        }
    }

    fun toggleZoneAutoFilter(zone: FocusZone, enabled: Boolean) {
        viewModelScope.launch {
            repository.updateZone(zone.copy(autoFilterEnabled = enabled))
            wifiMonitor.updateWifiState()
        }
    }

    fun showAddZoneDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showAddZoneDialog = show)
    }

    override fun onCleared() {
        super.onCleared()
        stopTimer()
        usageWatcherJob?.cancel()
        wifiMonitor.stopMonitoring()
    }
}
